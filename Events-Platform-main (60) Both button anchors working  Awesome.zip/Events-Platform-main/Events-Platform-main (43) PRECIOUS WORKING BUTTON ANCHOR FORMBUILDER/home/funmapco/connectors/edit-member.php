<?php
// Alias wrapper for update-member to support new action name without breaking callers
require_once __DIR__ . '/update-member.php';
?>

