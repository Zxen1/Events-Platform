<?php
// Alias wrapper for update-post to support new action name without breaking callers
require_once __DIR__ . '/update-post.php';
?>

